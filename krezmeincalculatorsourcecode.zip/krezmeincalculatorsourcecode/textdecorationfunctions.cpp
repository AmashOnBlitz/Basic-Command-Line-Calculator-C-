#include <iostream>
#include <string>
#include "textdecorationfunctions.h"

 std::string coutGreenText(std::string texttaken) {
	return "\033[32m" + texttaken + "\033[0m";
}

 std::string coutRedText(std::string texttaken) {
	return "\033[31m" + texttaken + "\033[0m";
}

 std::string coutBoldText(std::string texttaken) {
	return "\033[1m" + texttaken + "\033[0m";
}

 std::string coutUnderlineText(std::string texttaken) {
	return "\033[4m" + texttaken + "\033[0m";
}

 std::string coutInvertedText(std::string texttaken) {
	return "\033[7m" + texttaken + "\033[0m";
}

 std::string coutBoldGreenText(std::string texttaken) {
	return "\033[1;32m" + texttaken + "\033[0m";
}

 std::string coutBoldRedText(std::string texttaken) {
	return "\033[1;31m" + texttaken + "\033[0m";
}

 std::string coutBoldUnderlineText(std::string texttaken) {
	return "\033[1;4m" + texttaken + "\033[0m";
}

 std::string coutBoldInvertedText(std::string texttaken) {
	return "\033[1;7m" + texttaken + "\033[0m";
}

 std::string coutYellowText(std::string texttaken) {
	return "\033[33m" + texttaken + "\033[0m";
}

 std::string coutBoldYellowText(std::string texttaken) {
	 return "\033[1;33m" + texttaken + "\033[0m";
 }

 std::string coutBoldItalicRedText(std::string texttaken) {
	 return "\033[1;3;31m" + texttaken + "\033[0m";
 }