#include <iostream>
#include <string>
#include "Calculation.h"
#include "Generalcalulator.h"
#include "main.h"
#include "textdecorationfunctions.h"
#include "ScientificCalculator.h"


int commandcheckret(std::string commandEntered);

int returnMain() {
	std::string commandEntered = "Hello";
	std::cout << "Krezmein >";
	std::getline(std::cin, commandEntered);
	if (commandEntered == "--help") {
		help();
	}
	else if (commandEntered == "--start -Gen") {
		std::cout << coutGreenText("Welcome to General Calculator") << std::endl;
		startGeneralCalculator();
		returnMain();
	}
	else if (commandEntered == "--start -Sci") {
		std::cout << coutGreenText("Welcome to Scientific Calculator") << std::endl;
		startScientificCalculator();
	}
	else {
		while (commandEntered != "--help" && commandEntered != "--start -Gen" && commandEntered != "--start -Sci") {
			std::cout << coutBoldItalicRedText("Invalid command") << std::endl;
			std::cout << "Krezmein >";
			std::getline(std::cin, commandEntered);
			commandcheck(commandEntered);
		}

	}

	return 0;
}






int help() {
	std::string commandEntered;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << coutBoldYellowText("--start -Gen   :    Start a general calcultor") << std::endl;
	std::cout << coutBoldYellowText("--start -Sci   :    Start a scientific calculator") << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << "Krezmein >";
	std::getline(std::cin, commandEntered);
	if (commandEntered == "--help") {
		help();
	}
	else if (commandEntered == "--start -Gen") {
		std::cout << coutGreenText("Welcome to General Calculator") << std::endl;
		startGeneralCalculator();
	}
	else if (commandEntered == "--start -Sci") {
		std::cout << coutGreenText("Welcome to Scientific Calculator") << std::endl;
		startScientificCalculator();
	}
	else {
		while (commandEntered != "--help" && commandEntered != "--start -Gen" && commandEntered != "--start -Sci") {
			std::cout << coutBoldItalicRedText("Invalid command") << std::endl;
			std::cout << "Krezmein >";
			std::getline(std::cin, commandEntered);
			commandcheck(commandEntered);
		}

	}
	return 0;
}

int commandcheck(std::string commandtaken) {
	if (commandtaken == "--help") {
		help();
	}
	else if (commandtaken == "--start -Gen") {
		std::cout << coutGreenText("Welcome to General Calculator") << std::endl;
		startGeneralCalculator();
	}
	else if (commandtaken == "--start -Sci") {
		std::cout << coutGreenText("Welcome to Scientific Calculator") << std::endl;
		startScientificCalculator();
	}
	else {
		std::cout << coutBoldItalicRedText("Invalid command") << std::endl;
		std::cout << "Krezmein >";
		std::getline(std::cin, commandtaken);
		commandcheck(commandtaken);
	}
	return 0;
}