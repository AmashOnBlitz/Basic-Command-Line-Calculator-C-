#include <iostream>
#include <string>
#include "Calculation.h"
#include "Generalcalulator.h"
#include "main.h"

int startGeneralCalculator() {
	double num1;
	double num2 = 0;
	double num3 = 0;
	char isOtherNo;
	int caseNumber = 0;
	char returnHome;

	std::cout << "Enter the number one : ";
	std::cin >> num1;
	std::cout << "Enter the number two : ";
	std::cin >> num2;
	std::cout << "any other number [Y/n] : ";
	std::cin >> isOtherNo;

	if (isOtherNo == 'Y') {
		std::cout << "Enter the third no :";
		std::cin >> num3;
	}


	std::cout << "\033[31m" << "What Opr do you want to do?" << std::endl << "1 (Addition)" << std::endl;
	std::cout << "2 (Subtraction)" << std::endl << "3 (Multiplication)" << std::endl << "4 (Division)" << "\033[0m" << std::endl;
	std::cin >> caseNumber;

	switch (caseNumber)
	{
	case 1:
		if (isOtherNo == 'Y') {
			std::cout << "\033[32m" << "Your addition result is : " << "\033[0m5" << add(num1, num2, num3, 1);
		}
		else {
			std::cout << "\033[32m" << "Your addition result is : " << "\033[0m" << add(num1, num2, num3, 0);
		}
		break;

	case 2:
		if (isOtherNo == 'Y') {
			std::cout << "\033[32m" << "Your substraction result is : " << "\033[0m" << substraction(num1, num2, num3, 1);
		}
		else {
			std::cout << "\033[32m" << "Your substraction result is : " << "\033[0m" << substraction(num1, num2, num3, 0);
		}
		break;

	case 3:
		if (isOtherNo == 'Y') {
			std::cout << "\033[32m" << "Your multiplication result is : " << "\033[0m" << multiplication(num1, num2, num3, 1);
		}
		else {
			std::cout << "\033[32m" << "Your multiplication result is : " << "\033[0m" << multiplication(num1, num2, num3, 0);
		}
		break;

	case 4:
		if (isOtherNo == 'Y') {
			std::cout << "\033[32m" << "Your division result is : " << "\033[0m" << division(num1, num2, num3, 1);
		}
		else {
			std::cout << "\033[32m" << "Your division result is : " << "\033[0m" << division(num1, num2, num3, 0);
		}
		break;
	default:
		break;
	}

	std::cout << std::endl;
	
	return 0;
}