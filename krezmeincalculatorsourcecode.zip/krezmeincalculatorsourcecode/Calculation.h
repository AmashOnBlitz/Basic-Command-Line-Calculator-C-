
int add(double num1, double num2, double num3, int numIsMoreThan2);
int substraction(double num1, double num2, double num3, int numIsMoreThan2);
int multiplication(double num1, double num2, double num3, int numIsMoreThan2);
int division(double num1, double num2, double num3, int numIsMoreThan2);