#include "Calculation.h"
int add(double num1, double num2, double num3, int numIsMoreThan2) {
	if (numIsMoreThan2 == 0) {
		double result = num1 + num2;
		return result;
	}
	else {
		double result = num1 + num2 + num3;
		return result;
	}
}

int substraction (double num1, double num2, double num3, int numIsMoreThan2) {
	if (numIsMoreThan2 == 0) {
		double result = num1 - num2;
		return result;
	}
	else {
		double result = num1 - num2 - num3;
		return result;
	}
}

int multiplication(double num1, double num2, double num3, int numIsMoreThan2) {
	if (numIsMoreThan2 == 0) {
		 long double result = num1 * num2;
		return result;
	}
	else {
		 long double result = num1 * num2 * num3;
		return result;
	}
}

int division(double num1, double num2, double num3, int numIsMoreThan2) {
	if (numIsMoreThan2 == 0) {
		double result = num1 / num2;
		return result;
	}
	else {
		double result = num1 / num2 / num3;
		return result;
	}
}