#include <iostream>
#include <string>
std::string coutGreenText(std::string texttaken) {
	std::cout << texttaken << std::endl;
}