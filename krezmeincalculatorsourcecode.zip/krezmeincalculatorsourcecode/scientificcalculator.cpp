#include <iostream>
#include <string>
#include <cmath>
#include "Calculation.h"
#include "Generalcalulator.h"
#include "main.h"
#include "textdecorationfunctions.h"
#include "ScientificCalculator.h"

int startScientificCalculator() {
    double num1;
    double num2 = 0;
    double num3 = 0;
    char isOtherNo;
    int caseNumber = 0;
    char returnHome;

    std::cout << "Enter the number one : ";
    std::cin >> num1;
    std::cout << "Enter the number two : ";
    std::cin >> num2;
    std::cout << "any other number [Y/n] : ";
    std::cin >> isOtherNo;

    if (isOtherNo == 'Y') {
        std::cout << "Enter the third no :";
        std::cin >> num3;
    }

    std::cout << "\033[31m" << "What Opr do you want to do?" << std::endl;
    std::cout << "1 (Addition)" << std::endl;
    std::cout << "2 (Subtraction)" << std::endl;
    std::cout << "3 (Multiplication)" << std::endl;
    std::cout << "4 (Division)" << std::endl;
    std::cout << "5 (Power)" << std::endl;
    std::cout << "6 (Square Root)" << std::endl;
    std::cout << "7 (Logarithm)" << std::endl;
    std::cout << "8 (Sine)" << std::endl;
    std::cout << "9 (Cosine)" << std::endl;
    std::cout << "10 (Tangent)" << "\033[0m" << std::endl;
    std::cin >> caseNumber;

    switch (caseNumber)
    {
    case 1:
        if (isOtherNo == 'Y') {
            std::cout << "\033[32m" << "Your addition result is : " << "\033[0m" << add(num1, num2, num3, 1) << std::endl;
        }
        else {
            std::cout << "\033[32m" << "Your addition result is : " << "\033[0m" << add(num1, num2, num3, 0) << std::endl;
        }
        break;

    case 2:
        if (isOtherNo == 'Y') {
            std::cout << "\033[32m" << "Your substraction result is : " << "\033[0m" << substraction(num1, num2, num3, 1) << std::endl;
        }
        else {
            std::cout << "\033[32m" << "Your substraction result is : " << "\033[0m" << substraction(num1, num2, num3, 0) << std::endl;
        }
        break;

    case 3:
        if (isOtherNo == 'Y') {
            std::cout << "\033[32m" << "Your multiplication result is : " << "\033[0m" << multiplication(num1, num2, num3, 1) << std::endl;
        }
        else {
            std::cout << "\033[32m" << "Your multiplication result is : " << "\033[0m" << multiplication(num1, num2, num3, 0) << std::endl;
        }
        break;

    case 4:
        if (isOtherNo == 'Y') {
            std::cout << "\033[32m" << "Your division result is : " << "\033[0m" << division(num1, num2, num3, 1) << std::endl;
        }
        else {
            std::cout << "\033[32m" << "Your division result is : " << "\033[0m" << division(num1, num2, num3, 0) << std::endl;
        }
        break;

    case 5:
        if (isOtherNo == 'y') {
			std::cout << coutBoldItalicRedText("Power can be done for only first two numbers !") << std::endl;
            std::cout<<("Your power result of num 1 and 2  is : ", pow(num1, num2));
        }
        std::cout << "\033[32m" << "Your power result of num 1 and 2  is : " << "\033[0m" << pow(num1, num2) << std::endl;
        break;

    case 6:
        std::cout << "\033[32m" << "Your square root of"<<num1<<" is : " << "\033[0m" << sqrt(num1)<<std::endl;
        std::cout << "\033[32m" << "Your square root of"<<num2<< " is : " << "\033[0m" << sqrt(num2)<< std::endl;
        std::cout << "\033[32m" << "Your square root of"<<num3<<" is : " << "\033[0m" << sqrt(num3) << std::endl;
        break;

    case 7:
        std::cout << "\033[32m" << "Your logarithm result for "<<num1 <<"is : " << "\033[0m" << log(num1) << std::endl;
		std::cout << "\033[32m" << "Your logarithm result for"<<num2 <<" is : " << "\033[0m" << log(num2) << std::endl;
		if (isOtherNo == 'Y') {
			std::cout << "\033[32m" << "Your logarithm result for" << num3 << " is : " << "\033[0m" << log(num3) << std::endl;
            }
        break;

    case 8:
        std::cout << "\033[32m" << "Your sine result for"<<num1 <<" is : " << "\033[0m" << sin(num1) << std::endl;
		std::cout << "\033[32m" << "Your sine result for" << num2 << " is : " << "\033[0m" << sin(num2) << std::endl;
        if (isOtherNo == 'Y') {
            std::cout << "\033[32m" << "Your sine result for" << num3 << " is : " << "\033[0m" << sin(num3) << std::endl;
        }
        break;

    case 9:
        std::cout << "\033[32m" << "Your cosine result for"<<num1<<" is : " << "\033[0m" << cos(num1) << std::endl;
		std::cout << "\033[32m" << "Your cosine result for" << num2 << " is : " << "\033[0m" << cos(num2) << std::endl;
		if (isOtherNo == 'Y') {
			std::cout << "\033[32m" << "Your cosine result for" << num3 << " is : " << "\033[0m" << cos(num3) << std::endl;
		}
        break;

    case 10:
        std::cout << "\033[32m" << "Your tangent result for"<<num1<<" is : " << "\033[0m" << tan(num1) << std::endl;
		std::cout << "\033[32m" << "Your tangent result for" << num2 << " is : " << "\033[0m" << tan(num2) << std::endl;
		if (isOtherNo == 'Y') {
			std::cout << "\033[32m" << "Your tangent result for" << num3 << " is : " << "\033[0m" << tan(num3) << std::endl;
		}
        break;

    default:
        std::cout << "\033[31m" << "Invalid operation!" << "\033[0m" << std::endl;
        break;
    }

    std::cout << std::endl;
    std::cout << "Press Enter key to exit..." << std::endl;
    std::cin.ignore();
    std::cin.get();

    return 0;
}
