int startGeneralCalculator();
